-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2021 at 10:09 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admission`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `id` int(10) NOT NULL,
  `u_card` varchar(12) NOT NULL,
  `u_f_name` text NOT NULL,
  `u_l_name` text NOT NULL,
  `u_father` text NOT NULL,
  `u_aadhar` varchar(12) NOT NULL,
  `u_birthday` text NOT NULL,
  `u_gender` varchar(6) NOT NULL,
  `u_email` text NOT NULL,
  `u_phone` varchar(10) NOT NULL,
  `u_state` varchar(12) NOT NULL,
  `u_dist` text NOT NULL,
  `u_village` text NOT NULL,
  `u_police` text NOT NULL,
  `u_pincode` text NOT NULL,
  `file` longblob NOT NULL,
  `u_mother` varchar(30) NOT NULL,
  `u_family` text NOT NULL,
  `staff_id` varchar(12) NOT NULL,
  `image` varchar(150) NOT NULL,
  `uploaded` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`id`, `u_card`, `u_f_name`, `u_l_name`, `u_father`, `u_aadhar`, `u_birthday`, `u_gender`, `u_email`, `u_phone`, `u_state`, `u_dist`, `u_village`, `u_police`, `u_pincode`, `file`, `u_mother`, `u_family`, `staff_id`, `image`, `uploaded`) VALUES
(115, 'asdf', 'asdf', '', '', '', '', 'Choose', '', 'asdf', 'Choose...', '', '', '', '', '', '', '', '', '', '2021-07-18 12:25:22'),
(119, 'asdf', 'asdf', '', '', '', '', 'Choose', '', 'asdf', 'Choose...', '', '', '', '', '', '', '', '', '', '2021-07-18 12:29:24'),
(127, '111111', 'qqqq', 'wwww', 'qqqq', '', '', 'Choose', 'qqq@rr', '222222', 'Choose...', '', '', '', '', '', 'qqqq', '', '', '', '2021-10-23 01:30:20'),
(128, '111111', 'qqqq', 'wwww', 'qqqq', '', '', 'Choose', 'qqq@rr', '222222', 'Choose...', '', '', '', '', '', 'qqqq', '', '', '', '2021-10-23 04:05:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(5, 'kushkush', '$2y$10$pkgNOc0r6DaiDnCTIVT/VubRm0LqncpPgipzdARaH/9wZto.zmYLu', '2021-05-22 00:30:03'),
(6, '123123', '$2y$10$AwA0obkWAdzF6Z6zCqZ3Xu5QinFNWhL89iAUde8YYfYorruaxOjCm', '2021-07-17 16:49:54'),
(7, 'admin', '$2y$10$fKo2SrFCaO9b1JDAiLqkoOUbhOd0Xr1E61zlbkpFXztj0./mIEOWK', '2021-10-22 06:55:35'),
(8, 'lei', '$2y$10$OH6Svbmzr5B1aaSYetMo7Okeoq1zChuKoEPJ1AplqvVGkUSyNnO9S', '2021-10-22 07:02:44'),
(9, 'aaa', '$2y$10$yd4rdsoqpVegqKToXD/pkujbRK8eHvDPsGvzCns0TZicAFyJzlEPK', '2021-10-22 07:06:37'),
(10, 'iuiu', '$2y$10$MrudO6xlD8APfXphuETtveb3/6IxM0if5BT36Ei.gMmIkkmNcdcvy', '2021-10-22 07:54:57'),
(11, 'leii', '$2y$10$r0uqYaSbLSce0J.3oR/YVu28ylg5/VkUhy/MY/6HZ/CylAFUn/a5K', '2021-10-22 19:04:23'),
(12, 'okokok', '$2y$10$U6LfKqXIT3RkZZpDfsRaCOYc3CFXPItIdip6F.Gybr7LT2mCFhUta', '2021-10-22 21:12:34'),
(13, 'okokokok', '$2y$10$DQD.mjgpdFsO3l9FOm4iUe5KEM7m96Zf8MUchBJJgzwU.PRExt4tG', '2021-10-22 21:12:57'),
(14, 'qqq', '$2y$10$gQWfLeYvJjMirGo5L9jFxuR2RsA/ZKHbrc8wZNJLlYuwwQydUI7Gm', '2021-10-23 00:17:36'),
(15, 'hi1', '$2y$10$soLmepInGhzeLRDb.CsiR.tr604scNgR3jqquCZCout4AyYfTIINS', '2021-10-23 00:23:12'),
(16, 'trtr', '$2y$10$J9e0hlNWqLnRFJCt9Nsl1uJL1dpvPPvI6bP9CwffaRgjZb7DBH2zO', '2021-10-23 01:06:06'),
(17, 'iloveyou', '$2y$10$7QGaBQGRBX7FwIMcv9biG.fq1DUmyEaMaKDCAb2ifub9Gpk1JxpXO', '2021-10-23 01:27:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
